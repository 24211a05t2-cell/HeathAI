import { VitalSigns, VoiceSymptomData, ChestXRayData, TriageResult, UrgencyLevel, CovidRiskLevel } from '../types';

export function calculateTriageResult(
  vitals: VitalSigns,
  symptoms: VoiceSymptomData,
  xray?: ChestXRayData
): TriageResult {
  const riskFlags: string[] = [];
  const vitalWarnings: string[] = [];
  let urgencyScore = 20; // baseline score out of 100

  // 1. Vitals Analysis
  if (vitals.spo2 < 90) {
    urgencyScore += 45;
    vitalWarnings.push(`CRITICAL HYPOXIA: SpO₂ is ${vitals.spo2}% (Normal >= 95%)`);
    riskFlags.push(`Severe Oxygen Desaturation (${vitals.spo2}%)`);
  } else if (vitals.spo2 < 94) {
    urgencyScore += 25;
    vitalWarnings.push(`Borderline Hypoxia: SpO₂ is ${vitals.spo2}%`);
    riskFlags.push(`Moderate Oxygen Desaturation (${vitals.spo2}%)`);
  }

  if (vitals.temperature >= 102.0) {
    urgencyScore += 20;
    vitalWarnings.push(`High Fever: ${vitals.temperature}°F`);
    riskFlags.push(`Pyrexia (${vitals.temperature}°F)`);
  } else if (vitals.temperature >= 100.4) {
    urgencyScore += 10;
    vitalWarnings.push(`Fever: ${vitals.temperature}°F`);
  }

  if (vitals.heartRate > 110) {
    urgencyScore += 15;
    vitalWarnings.push(`Tachycardia: ${vitals.heartRate} bpm (Normal 60-100)`);
    riskFlags.push(`Elevated Heart Rate (${vitals.heartRate} bpm)`);
  }

  if (vitals.bpSystolic >= 160 || vitals.bpDiastolic >= 100) {
    urgencyScore += 15;
    vitalWarnings.push(`Stage 2 Hypertension: ${vitals.bpSystolic}/${vitals.bpDiastolic} mmHg`);
    riskFlags.push(`Hypertensive Crisis Risk`);
  }

  if (vitals.respiratoryRate > 24) {
    urgencyScore += 15;
    vitalWarnings.push(`Tachypnea: ${vitals.respiratoryRate} breaths/min`);
    riskFlags.push(`Rapid Respiratory Rate (${vitals.respiratoryRate} bpm)`);
  }

  // 2. Symptom Analysis
  if (symptoms.dyspneaSeverity === 'severe') {
    urgencyScore += 25;
    riskFlags.push('Severe Shortness of Breath (Dyspnea)');
  } else if (symptoms.dyspneaSeverity === 'moderate') {
    urgencyScore += 15;
    riskFlags.push('Moderate Shortness of Breath');
  }

  if (symptoms.lossOfSmellTaste) {
    urgencyScore += 15;
    riskFlags.push('Classic Anosmia / Loss of Taste');
  }

  if (symptoms.chestPain) {
    urgencyScore += 15;
    riskFlags.push('Chest Pain / Tightness');
  }

  if (symptoms.coughSeverity === 'severe') {
    urgencyScore += 10;
  }

  // 3. Chest X-Ray AI Analysis (COVID-Net classification)
  let covidRisk: CovidRiskLevel = 'Low Suspicion';
  
  if (xray) {
    const covidProb = xray.predictions.covid19;
    const nonCovidProb = xray.predictions.nonCovidInfection;

    if (covidProb >= 0.70) {
      urgencyScore += 35;
      covidRisk = 'High Suspicion';
      riskFlags.push(`COVID-Net CXR AI: High COVID-19 Viral Pneumonia Probability (${(covidProb * 100).toFixed(1)}%)`);
      if (xray.groundGlassOpacities) {
        riskFlags.push('Radiological Ground-Glass Opacities detected');
      }
    } else if (covidProb >= 0.35) {
      urgencyScore += 20;
      covidRisk = 'Moderate Suspicion';
      riskFlags.push(`COVID-Net CXR AI: Indeterminate / Suspicious COVID-19 features (${(covidProb * 100).toFixed(1)}%)`);
    } else if (nonCovidProb >= 0.60) {
      urgencyScore += 15;
      covidRisk = 'Low Suspicion';
      riskFlags.push(`COVID-Net CXR AI: Bacterial or Non-COVID Pneumonia (${(nonCovidProb * 100).toFixed(1)}%)`);
    } else {
      covidRisk = 'Unlikely';
    }
  } else {
    // Rely on symptoms + vitals for COVID suspicion
    if (symptoms.lossOfSmellTaste && (symptoms.feverPresent || vitals.temperature >= 100.4) && symptoms.dyspneaSeverity !== 'none') {
      covidRisk = 'High Suspicion';
    } else if (symptoms.feverPresent || symptoms.coughSeverity !== 'none') {
      covidRisk = 'Moderate Suspicion';
    }
  }

  // Cap urgency score at 100
  urgencyScore = Math.min(100, Math.max(5, urgencyScore));

  // Determine Urgency Level & Recommended Specialty
  let urgencyLevel: UrgencyLevel = 'Routine';
  let recommendedSpecialty = 'General Practice / Primary Care';
  let secondarySpecialty: string | undefined = undefined;
  let recommendedAction = 'Routine clinic consult or symptomatic home isolation';

  if (urgencyScore >= 75 || vitals.spo2 < 90 || (xray?.predictions.covid19 ?? 0) > 0.85) {
    urgencyLevel = 'Emergency';
    recommendedSpecialty = 'Pulmonology & Critical Care';
    secondarySpecialty = 'Infectious Diseases';
    recommendedAction = 'Immediate triage isolation ward, high-flow supplemental O₂, emergency MD assessment & RT-PCR lab testing';
  } else if (urgencyScore >= 50 || vitals.spo2 < 94 || symptoms.dyspneaSeverity === 'severe') {
    urgencyLevel = 'Urgent Care';
    recommendedSpecialty = 'Infectious Diseases / Respiratory Medicine';
    secondarySpecialty = 'Internal Medicine';
    recommendedAction = 'Priority urgent care evaluation within 1 hour, continuous pulse oximetry monitoring, blood gas assessment';
  } else if (urgencyScore >= 30 || symptoms.feverPresent || xray?.predictedClass === 'Non-COVID-19 Infection') {
    urgencyLevel = 'Moderate Priority';
    recommendedSpecialty = 'Internal Medicine';
    secondarySpecialty = 'Pulmonology';
    recommendedAction = 'Same-day outpatient medical consultation, sputum evaluation, empirical prescription review';
  }

  // Build rationale string
  const rationaleParts: string[] = [];
  if (vitals.spo2 < 92) rationaleParts.push(`SpO₂ level of ${vitals.spo2}% indicates acute hypoxemia requiring immediate oxygenation.`);
  if (xray) rationaleParts.push(`Chest radiography AI classification shows ${xray.predictedClass} with ${(xray.confidenceScore).toFixed(1)}% confidence.`);
  if (symptoms.extractedSymptoms.length > 0) rationaleParts.push(`Reported symptoms include: ${symptoms.extractedSymptoms.slice(0, 4).join(', ')}.`);
  if (vitalWarnings.length > 0) rationaleParts.push(`Vital sign anomalies: ${vitalWarnings.join('; ')}.`);

  const rationale = rationaleParts.join(' ') || 'Symptom and vital profile evaluated under standard clinical triage protocol.';

  return {
    urgencyLevel,
    urgencyScore,
    recommendedSpecialty,
    secondarySpecialty,
    recommendedAction,
    covidRisk,
    riskFlags,
    vitalSignWarnings: vitalWarnings,
    rationale,
    timestamp: new Date().toISOString()
  };
}
