import { PatientProfile } from '../types';
import { SAMPLE_CHEST_XRAYS } from './sampleXRays';

export const INITIAL_SAMPLE_PATIENTS: PatientProfile[] = [
  {
    id: 'pat-001',
    patientId: 'PAT-2026-9041',
    name: 'Marcus Vance',
    age: 58,
    gender: 'Male',
    phone: '+1 (555) 234-8891',
    medicalHistory: ['Hypertension', 'Type 2 Diabetes'],
    createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    vitals: {
      spo2: 89, // Critical hypoxia < 90%
      bpSystolic: 148,
      bpDiastolic: 92,
      heartRate: 112, // Tachycardia
      temperature: 102.4, // High fever
      weight: 84,
      respiratoryRate: 26 // Tachypnea
    },
    symptoms: {
      rawTranscript: "I've been feeling extremely short of breath for the last 3 days. High fever around 102 degrees, dry severe cough, total loss of taste and smell, and severe fatigue.",
      extractedSymptoms: ["Severe Dyspnea (Shortness of breath)", "High Fever (102.4°F)", "Dry Cough", "Anosmia / Loss of Smell", "Agegeia / Loss of Taste", "Severe Fatigue"],
      onsetDays: 4,
      feverPresent: true,
      coughSeverity: 'severe',
      dyspneaSeverity: 'severe',
      lossOfSmellTaste: true,
      fatigue: true,
      chestPain: true,
      otherSymptoms: "Muscle aches and headache",
      additionalNotes: "Patient appears visibly dyspneic at rest. Immediate oxygen therapy recommended."
    },
    xray: SAMPLE_CHEST_XRAYS.covid_severe,
    triage: {
      urgencyLevel: 'Emergency',
      urgencyScore: 96,
      recommendedSpecialty: 'Pulmonology & Critical Care',
      secondarySpecialty: 'Infectious Diseases',
      recommendedAction: 'Immediate isolation ward admission, high-flow nasal oxygen, emergency clinician review',
      covidRisk: 'High Suspicion',
      riskFlags: [
        'CRITICAL: Hypoxia (SpO₂ 89% on room air)',
        'CRITICAL: COVID-Net AI X-Ray Ground-Glass Opacities (94.2% COVID-19 probability)',
        'Severe Dyspnea + Tachypnea (26 bpm)',
        'High Fever (102.4°F)',
        'Comorbidities: Diabetes & Hypertension'
      ],
      vitalSignWarnings: [
        'SpO₂ 89% (Normal: 95-100%) - Severe Hypoxia',
        'Heart Rate 112 bpm - Tachycardia',
        'Temperature 102.4°F - Pyrexia',
        'Respiratory Rate 26 bpm - Tachypnea'
      ],
      rationale: 'Patient meets criteria for Emergency COVID-19 Triage due to acute respiratory failure risk (SpO₂ 89%), high viral pneumonia likelihood on CXR, and classic triad of anosmia, severe dyspnea, and high fever.',
      timestamp: new Date(Date.now() - 1000 * 60 * 20).toISOString()
    },
    doctorReview: {
      reviewedBy: 'Dr. Sarah Lin, MD (Attending Pulmonologist)',
      status: 'Approved',
      clinicalNotes: 'Triage recommendation confirmed. Patient transferred to Negative Pressure Isolation Room 4B. Arterial blood gas (ABG) and RT-PCR nasal swab ordered.',
      reviewedAt: new Date(Date.now() - 1000 * 60 * 10).toISOString()
    }
  },
  {
    id: 'pat-002',
    patientId: 'PAT-2026-9042',
    name: 'Elena Rostova',
    age: 34,
    gender: 'Female',
    phone: '+1 (555) 871-3342',
    medicalHistory: ['Asthma (Mild)'],
    createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    vitals: {
      spo2: 95,
      bpSystolic: 122,
      bpDiastolic: 78,
      heartRate: 88,
      temperature: 100.8,
      weight: 62,
      respiratoryRate: 19
    },
    symptoms: {
      rawTranscript: "I have had a wet productive cough with yellowish phlegm for 5 days. Low fever around 100.5, right side chest tightness when taking deep breaths. No loss of taste.",
      extractedSymptoms: ["Productive Cough", "Fever (100.8°F)", "Pleuritic Chest Pain", "Sputum Production"],
      onsetDays: 5,
      feverPresent: true,
      coughSeverity: 'moderate',
      dyspneaSeverity: 'mild',
      lossOfSmellTaste: false,
      fatigue: true,
      chestPain: true,
      otherSymptoms: "Mild body aches",
      additionalNotes: "Productive cough with localized chest pain."
    },
    xray: SAMPLE_CHEST_XRAYS.non_covid_pneumonia,
    triage: {
      urgencyLevel: 'Moderate Priority',
      urgencyScore: 58,
      recommendedSpecialty: 'General Internal Medicine',
      secondarySpecialty: 'Pulmonology',
      recommendedAction: 'Outpatient or observation unit evaluation, sputum culture, empirical oral antibiotic therapy',
      covidRisk: 'Low Suspicion',
      riskFlags: [
        'COVID-Net CXR indicates Bacterial Pneumonia pattern (88.5% Non-COVID)',
        'Productive sputum cough + unilateral chest pain',
        'Moderate Fever (100.8°F)'
      ],
      vitalSignWarnings: [
        'Temperature 100.8°F - Mild Pyrexia'
      ],
      rationale: 'Clinical features and focal lower lobe consolidation on CXR point towards community-acquired bacterial pneumonia. SpO₂ is stable at 95%.',
      timestamp: new Date(Date.now() - 1000 * 60 * 50).toISOString()
    },
    doctorReview: {
      reviewedBy: 'Dr. James Miller, MD',
      status: 'Pending',
      clinicalNotes: '',
      reviewedAt: ''
    }
  },
  {
    id: 'pat-003',
    patientId: 'PAT-2026-9043',
    name: 'David Kim',
    age: 27,
    gender: 'Male',
    phone: '+1 (555) 412-9900',
    medicalHistory: ['None'],
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    vitals: {
      spo2: 99,
      bpSystolic: 118,
      bpDiastolic: 76,
      heartRate: 72,
      temperature: 98.6,
      weight: 75,
      respiratoryRate: 14
    },
    symptoms: {
      rawTranscript: "Just slight nasal congestion and mild sore throat for 2 days. No fever, breathing is totally fine, taste and smell are normal.",
      extractedSymptoms: ["Nasal Congestion", "Mild Sore Throat"],
      onsetDays: 2,
      feverPresent: false,
      coughSeverity: 'none',
      dyspneaSeverity: 'none',
      lossOfSmellTaste: false,
      fatigue: false,
      chestPain: false,
      otherSymptoms: "None",
      additionalNotes: "Patient requesting pre-employment clearance."
    },
    xray: SAMPLE_CHEST_XRAYS.normal_cxr,
    triage: {
      urgencyLevel: 'Routine',
      urgencyScore: 15,
      recommendedSpecialty: 'General Practice / Primary Care',
      recommendedAction: 'Standard outpatient consult or home symptomatic management',
      covidRisk: 'Unlikely',
      riskFlags: [],
      vitalSignWarnings: [],
      rationale: 'All vital signs are strictly within normal limits. Chest radiograph clear (98.0% normal). Symptoms isolated to upper respiratory tract.',
      timestamp: new Date(Date.now() - 1000 * 60 * 115).toISOString()
    },
    doctorReview: {
      reviewedBy: 'Dr. James Miller, MD',
      status: 'Approved',
      clinicalNotes: 'Cleared for standard outpatient care. No further imaging or isolation required.',
      reviewedAt: new Date(Date.now() - 1000 * 60 * 90).toISOString()
    }
  }
];
