import { CovidNetBenchmarkMetrics } from '../types';

export const COVID_NET_PAPER_BENCHMARKS: CovidNetBenchmarkMetrics = {
  accuracy: 93.3,
  covid19Sensitivity: 91.0, // Recall: 91.0% (crucial to limit false negatives in triage)
  covid19PPV: 98.9, // Positive Predictive Value / Precision
  covid19Specificity: 99.4,
  overallF1Score: 94.8,
  totalTestCases: 1579,
  confusionMatrix: [
    { actual: 'COVID-19 Infection', predicted: 'COVID-19 Infection', count: 91, percentage: 91.0 },
    { actual: 'COVID-19 Infection', predicted: 'Non-COVID-19 Infection', count: 7, percentage: 7.0 },
    { actual: 'COVID-19 Infection', predicted: 'Normal / No Infection', count: 2, percentage: 2.0 },

    { actual: 'Non-COVID-19 Infection', predicted: 'COVID-19 Infection', count: 1, percentage: 0.1 },
    { actual: 'Non-COVID-19 Infection', predicted: 'Non-COVID-19 Infection', count: 887, percentage: 94.2 },
    { actual: 'Non-COVID-19 Infection', predicted: 'Normal / No Infection', count: 54, percentage: 5.7 },

    { actual: 'Normal / No Infection', predicted: 'COVID-19 Infection', count: 0, percentage: 0.0 },
    { actual: 'Normal / No Infection', predicted: 'Non-COVID-19 Infection', count: 42, percentage: 7.8 },
    { actual: 'Normal / No Infection', predicted: 'Normal / No Infection', count: 495, percentage: 92.2 },
  ]
};

export const CLINICAL_SAFETY_EXPLANATION = {
  title: "Why COVID-19 Sensitivity / Recall is the Headline Metric",
  body: `In emergency triage and infectious disease screening, a False Negative (a patient with COVID-19 misclassified as Normal or Non-COVID) is far more dangerous than a False Positive. A missed COVID-19 patient may be discharged or sent to a standard waiting room, risking severe respiratory decline and causing nosocomial disease transmission. COVID-Net specifically architecturalized its deep network design and loss function weightings to maximize COVID-19 Sensitivity (achieving 91.0% recall on test data with 98.9% Positive Predictive Value).`,
  keyTakeaways: [
    "Minimizes False Negatives: Prevents unmonitored discharge of contagious or worsening patients.",
    "Bilateral Ground-Glass Opacity Focus: Leverages feature maps detecting peripheral & basal consolidations.",
    "Integrated Decision Support: Complements voice symptoms and vital sign thresholds (e.g. SpO₂ < 92%)."
  ]
};
