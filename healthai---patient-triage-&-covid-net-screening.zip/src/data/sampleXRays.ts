import { ChestXRayData } from '../types';

// Utility helper to create stylized high-quality chest X-ray SVG data URLs
export function createSampleXRaySvg(type: 'covid' | 'pneumonia' | 'normal'): string {
  let overlayVisuals = '';
  let bgGradient = '';

  if (type === 'covid') {
    bgGradient = `<radialGradient id="covidGlow" cx="65%" cy="45%" r="35%"><stop offset="0%" stop-color="#ef4444" stop-opacity="0.65"/><stop offset="50%" stop-color="#f97316" stop-opacity="0.3"/><stop offset="100%" stop-color="#000000" stop-opacity="0"/></radialGradient>`;
    overlayVisuals = `
      <!-- Bilateral peripheral ground-glass opacities (red/amber heat overlay) -->
      <path d="M 120 160 Q 100 240 130 320 Q 180 340 190 260 Q 180 180 120 160 Z" fill="url(#covidGlow)" filter="blur(8px)"/>
      <path d="M 280 160 Q 300 240 270 320 Q 220 340 210 260 Q 220 180 280 160 Z" fill="url(#covidGlow)" filter="blur(8px)"/>
      <circle cx="150" cy="270" r="45" fill="#ef4444" opacity="0.35" filter="blur(12px)"/>
      <circle cx="250" cy="280" r="50" fill="#ef4444" opacity="0.35" filter="blur(12px)"/>
      <circle cx="130" cy="220" r="30" fill="#f97316" opacity="0.3" filter="blur(10px)"/>
      <circle cx="270" cy="230" r="35" fill="#f97316" opacity="0.3" filter="blur(10px)"/>
    `;
  } else if (type === 'pneumonia') {
    bgGradient = `<radialGradient id="pneuGlow" cx="30%" cy="60%" r="30%"><stop offset="0%" stop-color="#eab308" stop-opacity="0.6"/><stop offset="100%" stop-color="#000000" stop-opacity="0"/></radialGradient>`;
    overlayVisuals = `
      <!-- Focal right lower lobe consolidation (yellow/amber heat overlay) -->
      <path d="M 110 240 Q 100 310 160 330 Q 180 290 150 240 Z" fill="url(#pneuGlow)" filter="blur(8px)"/>
      <circle cx="135" cy="275" r="40" fill="#eab308" opacity="0.4" filter="blur(10px)"/>
    `;
  } else {
    // Normal: clear lung fields, soft blue/green subtle overlay
    overlayVisuals = `
      <circle cx="150" cy="250" r="30" fill="#10b981" opacity="0.08" filter="blur(10px)"/>
      <circle cx="250" cy="250" r="30" fill="#10b981" opacity="0.08" filter="blur(10px)"/>
    `;
  }

  const svgString = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 450" width="100%" height="100%">
    <defs>
      <linearGradient id="ribGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.8"/>
        <stop offset="100%" stop-color="#64748b" stop-opacity="0.2"/>
      </linearGradient>
      ${bgGradient}
    </defs>
    <!-- Background Chest Radiology Canvas -->
    <rect width="400" height="450" fill="#090d16"/>
    
    <!-- Spine & Clavicles -->
    <rect x="195" y="40" width="10" height="370" fill="#cbd5e1" opacity="0.75" rx="3"/>
    <path d="M 80 80 Q 200 100 320 80" stroke="#f1f5f9" stroke-width="8" fill="none" opacity="0.8" stroke-linecap="round"/>
    
    <!-- Left & Right Lung Field Contours -->
    <path d="M 180 110 C 110 110 80 180 80 330 C 130 360 185 340 185 280 C 185 200 185 140 180 110 Z" fill="#1e293b" stroke="#475569" stroke-width="2"/>
    <path d="M 220 110 C 290 110 320 180 320 330 C 270 360 215 340 215 280 C 215 200 215 140 220 110 Z" fill="#1e293b" stroke="#475569" stroke-width="2"/>
    
    <!-- Heart Silhouette -->
    <path d="M 195 210 Q 250 260 215 330 Q 180 320 195 210 Z" fill="#64748b" opacity="0.85"/>
    
    <!-- Ribcage arcs -->
    <path d="M 195 130 Q 120 150 90 190 M 195 130 Q 280 150 310 190" stroke="url(#ribGrad)" stroke-width="4" fill="none"/>
    <path d="M 195 170 Q 110 190 85 240 M 195 170 Q 290 190 315 240" stroke="url(#ribGrad)" stroke-width="4" fill="none"/>
    <path d="M 195 210 Q 100 230 82 290 M 195 210 Q 300 230 318 290" stroke="url(#ribGrad)" stroke-width="4" fill="none"/>
    <path d="M 195 250 Q 95 270 85 330 M 195 250 Q 305 270 315 330" stroke="url(#ribGrad)" stroke-width="4" fill="none"/>
    
    <!-- Diaphragm -->
    <path d="M 60 350 Q 140 320 195 345 Q 260 320 340 350" stroke="#e2e8f0" stroke-width="5" fill="none" opacity="0.9"/>
    
    ${overlayVisuals}

    <!-- Orientation Marker -->
    <text x="20" y="40" fill="#94a3b8" font-family="monospace" font-size="16" font-weight="bold">R</text>
    <text x="360" y="40" fill="#94a3b8" font-family="monospace" font-size="16" font-weight="bold">L</text>
    <text x="20" y="430" fill="#64748b" font-family="sans-serif" font-size="11">CXR PA View | COVID-Net v4 AI</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svgString)}`;
}

export const SAMPLE_CHEST_XRAYS: Record<string, ChestXRayData> = {
  covid_severe: {
    imageUrl: createSampleXRaySvg('covid'),
    imageName: 'CXR_Patient_Covid19_Bilateral_GGO.png',
    isCustomUpload: false,
    predictions: {
      covid19: 0.942,
      nonCovidInfection: 0.048,
      normal: 0.010
    },
    predictedClass: 'COVID-19 Infection',
    confidenceScore: 94.2,
    findings: [
      "Bilateral multifocal ground-glass opacities (GGO)",
      "Peripheral & lower zone distribution typical of viral pneumonia",
      "Crazy-paving pattern identified in middle/lower lung zones",
      "No pneumothorax or pleural effusion observed"
    ],
    radiologyNotes: "High-probability COVID-19 viral pneumonia pattern with extensive bilateral lower-lobe consolidation. High infectious triage status recommended.",
    heatmapCoordinates: [
      { x: 32, y: 58, radius: 45, intensity: 0.92, label: 'Right Lower Zone GGO' },
      { x: 68, y: 60, radius: 50, intensity: 0.88, label: 'Left Lower Zone GGO' },
      { x: 30, y: 46, radius: 30, intensity: 0.65, label: 'Right Mid Zone Opacity' },
      { x: 70, y: 48, radius: 35, intensity: 0.70, label: 'Left Mid Zone Opacity' }
    ],
    bilateralInfiltrates: true,
    groundGlassOpacities: true
  },
  non_covid_pneumonia: {
    imageUrl: createSampleXRaySvg('pneumonia'),
    imageName: 'CXR_Patient_Bacterial_Pneumonia.png',
    isCustomUpload: false,
    predictions: {
      covid19: 0.062,
      nonCovidInfection: 0.885,
      normal: 0.053
    },
    predictedClass: 'Non-COVID-19 Infection',
    confidenceScore: 88.5,
    findings: [
      "Focal lobar consolidation in right lower lobe",
      "Air bronchograms noted within dense consolidation area",
      "Left lung field is clear without GGO",
      "Minimal right costophrenic angle blunting"
    ],
    radiologyNotes: "Radiological features consistent with focal bacterial pneumonia (likely Streptococcus pneumoniae). Low suspicion for primary COVID-19 viral pattern.",
    heatmapCoordinates: [
      { x: 34, y: 62, radius: 40, intensity: 0.85, label: 'Right Lower Lobe Consolidation' }
    ],
    bilateralInfiltrates: false,
    groundGlassOpacities: false
  },
  normal_cxr: {
    imageUrl: createSampleXRaySvg('normal'),
    imageName: 'CXR_Patient_Normal_Clear.png',
    isCustomUpload: false,
    predictions: {
      covid19: 0.005,
      nonCovidInfection: 0.015,
      normal: 0.980
    },
    predictedClass: 'Normal / No Infection',
    confidenceScore: 98.0,
    findings: [
      "Both lung fields clear with normal vascular markings",
      "Cardiothoracic ratio within normal limits (< 0.5)",
      "Clear costophrenic angles bilaterally",
      "Bony thorax and soft tissues intact"
    ],
    radiologyNotes: "Unremarkable chest radiograph. No acute cardiopulmonary airspace disease detected.",
    heatmapCoordinates: [],
    bilateralInfiltrates: false,
    groundGlassOpacities: false
  }
};
