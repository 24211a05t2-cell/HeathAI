export type UrgencyLevel = 'Emergency' | 'Urgent Care' | 'Moderate Priority' | 'Routine';

export type CovidRiskLevel = 'High Suspicion' | 'Moderate Suspicion' | 'Low Suspicion' | 'Unlikely';

export type XRayClass = 'COVID-19 Infection' | 'Non-COVID-19 Infection' | 'Normal / No Infection';

export interface VitalSigns {
  spo2: number; // %
  bpSystolic: number; // mmHg
  bpDiastolic: number; // mmHg
  heartRate: number; // bpm
  temperature: number; // °F
  weight: number; // kg
  respiratoryRate: number; // breaths/min
}

export interface VoiceSymptomData {
  rawTranscript: string;
  extractedSymptoms: string[];
  onsetDays: number;
  feverPresent: boolean;
  coughSeverity: 'none' | 'mild' | 'moderate' | 'severe';
  dyspneaSeverity: 'none' | 'mild' | 'moderate' | 'severe';
  lossOfSmellTaste: boolean;
  fatigue: boolean;
  chestPain: boolean;
  otherSymptoms: string;
  additionalNotes: string;
}

export interface HeatmapPoint {
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  radius: number;
  intensity: number; // 0 to 1
  label: string;
}

export interface ChestXRayData {
  imageUrl: string;
  imageName: string;
  isCustomUpload: boolean;
  predictions: {
    covid19: number; // 0-1
    nonCovidInfection: number; // 0-1
    normal: number; // 0-1
  };
  predictedClass: XRayClass;
  confidenceScore: number;
  findings: string[];
  radiologyNotes: string;
  heatmapCoordinates: HeatmapPoint[];
  bilateralInfiltrates: boolean;
  groundGlassOpacities: boolean;
}

export interface TriageResult {
  urgencyLevel: UrgencyLevel;
  urgencyScore: number; // 1-100
  recommendedSpecialty: string;
  recommendedAction: string;
  secondarySpecialty?: string;
  covidRisk: CovidRiskLevel;
  riskFlags: string[];
  vitalSignWarnings: string[];
  rationale: string;
  timestamp: string;
}

export interface DoctorReview {
  reviewedBy: string;
  status: 'Pending' | 'Approved' | 'Overridden' | 'Discharged';
  overrideUrgency?: UrgencyLevel;
  overrideSpecialty?: string;
  clinicalNotes: string;
  reviewedAt: string;
}

export interface PatientProfile {
  id: string;
  patientId: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  phone: string;
  medicalHistory: string[];
  createdAt: string;
  vitals: VitalSigns;
  symptoms: VoiceSymptomData;
  xray?: ChestXRayData;
  triage?: TriageResult;
  doctorReview?: DoctorReview;
}

export interface ConfusionMatrixCell {
  actual: XRayClass;
  predicted: XRayClass;
  count: number;
  percentage: number;
}

export interface CovidNetBenchmarkMetrics {
  accuracy: number;
  covid19Sensitivity: number; // Recall - key safety metric!
  covid19PPV: number; // Precision
  covid19Specificity: number;
  overallF1Score: number;
  totalTestCases: number;
  confusionMatrix: ConfusionMatrixCell[];
}
