import React, { useState, useEffect } from 'react';
import { PatientProfile } from './types';
import { INITIAL_SAMPLE_PATIENTS } from './data/samplePatients';
import { Navbar } from './components/Navbar';
import { PatientIntakeForm } from './components/PatientIntakeForm';
import { DoctorDashboard } from './components/DoctorDashboard';
import { CovidNetMetricsView } from './components/CovidNetMetricsView';
import { ClinicalDemoSelector } from './components/ClinicalDemoSelector';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'intake' | 'dashboard' | 'metrics' | 'demos'>('intake');
  const [patients, setPatients] = useState<PatientProfile[]>(INITIAL_SAMPLE_PATIENTS);
  const [activeDemo, setActiveDemo] = useState<Partial<PatientProfile> | undefined>(undefined);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Fetch initial patients from server
  useEffect(() => {
    fetch('/api/patients')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data) && data.length > 0) {
          setPatients(data);
        }
      })
      .catch(err => console.warn("Using local patient store:", err));
  }, []);

  const handlePatientCreated = (newPatient: PatientProfile) => {
    setPatients(prev => [newPatient, ...prev]);
    showToast(`Patient ${newPatient.name} added to Doctor Queue (${newPatient.triage?.urgencyLevel} Triage)`);
  };

  const handleReviewUpdated = (patientId: string, reviewData: any) => {
    setPatients(prev => prev.map(p => p.id === patientId ? { ...p, doctorReview: reviewData } : p));
    showToast(`Doctor review updated for patient.`);
  };

  const handleSelectDemoScenario = (demoPatient: PatientProfile) => {
    setActiveDemo(demoPatient);
    setActiveTab('intake');
    showToast(`Loaded pre-configured clinical scenario: ${demoPatient.name}`);
  };

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 4000);
  };

  const pendingCount = patients.filter(p => p.doctorReview?.status === 'Pending').length;

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-900">
      
      {/* Top Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        pendingReviewCount={pendingCount}
      />

      {/* Toast Notification Floating Banner */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-teal-500/50 text-xs font-bold flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-teal-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="px-4 sm:px-6 lg:px-8 py-6 pb-16">
        {activeTab === 'intake' && (
          <div className="space-y-4">
            {activeDemo && (
              <div className="max-w-5xl mx-auto bg-amber-50 border border-amber-300 p-3.5 rounded-xl text-xs text-amber-900 flex items-center justify-between">
                <span>
                  Currently reviewing demo case: <strong>{activeDemo.name}</strong> ({activeDemo.triage?.urgencyLevel} Triage)
                </span>
                <button
                  onClick={() => setActiveDemo(undefined)}
                  className="text-amber-800 font-bold underline hover:text-amber-950"
                >
                  Reset Form
                </button>
              </div>
            )}
            <PatientIntakeForm
              onPatientCreated={handlePatientCreated}
              initialPatientData={activeDemo}
            />
          </div>
        )}

        {activeTab === 'dashboard' && (
          <DoctorDashboard
            patients={patients}
            onReviewUpdated={handleReviewUpdated}
          />
        )}

        {activeTab === 'metrics' && (
          <CovidNetMetricsView />
        )}

        {activeTab === 'demos' && (
          <ClinicalDemoSelector onSelectDemo={handleSelectDemoScenario} />
        )}
      </main>

      {/* Clinical Disclaimer Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-6 px-4 text-center text-xs space-y-1">
        <p className="font-semibold text-slate-300">
          HealthAI Clinical Decision Support Platform
        </p>
        <p className="max-w-3xl mx-auto text-slate-500 text-[11px] leading-relaxed">
          Important Disclaimer: HealthAI is intended strictly as an automated first-level triage and clinical decision-support assistant to help prioritize patient workflows. It is not a substitute for professional clinical judgment, laboratory RT-PCR diagnosis, or definitive physician examination.
        </p>
      </footer>

    </div>
  );
}
