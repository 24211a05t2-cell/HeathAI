import React, { useState } from 'react';
import { PatientProfile } from '../types';
import { HeatmapViewer } from './HeatmapViewer';
import { Activity, Stethoscope, AlertOctagon, CheckCircle2, ShieldAlert, User, Clock, FileText, Check, Edit3, Printer, Filter, Search, ChevronRight } from 'lucide-react';

interface DoctorDashboardProps {
  patients: PatientProfile[];
  onReviewUpdated: (patientId: string, reviewData: any) => void;
}

export const DoctorDashboard: React.FC<DoctorDashboardProps> = ({ patients, onReviewUpdated }) => {
  const [selectedId, setSelectedId] = useState<string>(patients[0]?.id || '');
  const [filterUrgency, setFilterUrgency] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Doctor Review Form state
  const [reviewerName, setReviewerName] = useState<string>('Dr. Sarah Lin, MD');
  const [notes, setNotes] = useState<string>('');
  const [reviewStatus, setReviewStatus] = useState<'Approved' | 'Overridden' | 'Discharged'>('Approved');
  const [overrideUrgency, setOverrideUrgency] = useState<string>('');
  const [overrideSpecialty, setOverrideSpecialty] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const selectedPatient = patients.find(p => p.id === selectedId) || patients[0];

  const filteredPatients = patients.filter(p => {
    if (filterUrgency !== 'All' && p.triage?.urgencyLevel !== filterUrgency) return false;
    if (filterStatus !== 'All' && p.doctorReview?.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return p.name.toLowerCase().includes(q) || p.patientId.toLowerCase().includes(q);
    }
    return true;
  });

  const handleSaveReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) return;

    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/patients/${selectedPatient.id}/review`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reviewedBy: reviewerName,
          status: reviewStatus,
          overrideUrgency: overrideUrgency || undefined,
          overrideSpecialty: overrideSpecialty || undefined,
          clinicalNotes: notes
        })
      });

      if (!res.ok) throw new Error('Failed to update review');

      const updated = await res.json();
      onReviewUpdated(selectedPatient.id, updated.doctorReview);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header Bar */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl flex flex-wrap items-center justify-between gap-4 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Stethoscope className="w-6 h-6 text-teal-400" />
            <h2 className="text-xl font-bold">Doctor Triage Review & Hospital Queue</h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time clinician dashboard for verifying, overriding, or approving AI pre-screening decisions
          </p>
        </div>

        {/* Stats Summary Badges */}
        <div className="flex items-center gap-3 text-xs">
          <div className="bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
            <span className="text-slate-400 block">Total Patients</span>
            <span className="text-base font-bold text-white">{patients.length}</span>
          </div>

          <div className="bg-rose-950/80 text-rose-300 px-3 py-1.5 rounded-xl border border-rose-800 font-bold">
            <span className="block text-rose-400 font-normal">Emergency</span>
            <span className="text-base font-bold text-rose-200">
              {patients.filter(p => p.triage?.urgencyLevel === 'Emergency').length}
            </span>
          </div>

          <div className="bg-amber-950/80 text-amber-300 px-3 py-1.5 rounded-xl border border-amber-800 font-bold">
            <span className="block text-amber-400 font-normal">Pending Review</span>
            <span className="text-base font-bold text-amber-200">
              {patients.filter(p => p.doctorReview?.status === 'Pending').length}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Queue Sidebar + Patient Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Patient Queue (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
          
          {/* Search & Filters */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search patient or ID..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-[10px] text-slate-500 font-semibold block mb-0.5">Urgency</label>
                <select
                  value={filterUrgency}
                  onChange={e => setFilterUrgency(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-md p-1.5 text-slate-700 text-xs"
                >
                  <option value="All">All Urgencies</option>
                  <option value="Emergency">Emergency</option>
                  <option value="Urgent Care">Urgent Care</option>
                  <option value="Moderate Priority">Moderate</option>
                  <option value="Routine">Routine</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-500 font-semibold block mb-0.5">MD Status</label>
                <select
                  value={filterStatus}
                  onChange={e => setFilterStatus(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-md p-1.5 text-slate-700 text-xs"
                >
                  <option value="All">All Statuses</option>
                  <option value="Pending">Pending</option>
                  <option value="Approved">Approved</option>
                  <option value="Overridden">Overridden</option>
                  <option value="Discharged">Discharged</option>
                </select>
              </div>
            </div>
          </div>

          {/* List of Queue Patients */}
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filteredPatients.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">No patient records match filter</p>
            ) : (
              filteredPatients.map(p => {
                const isSel = p.id === selectedPatient?.id;
                const isEmerg = p.triage?.urgencyLevel === 'Emergency';

                return (
                  <button
                    key={p.id}
                    onClick={() => {
                      setSelectedId(p.id);
                      setNotes(p.doctorReview?.clinicalNotes || '');
                      setReviewStatus((p.doctorReview?.status as any) || 'Approved');
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all relative ${
                      isSel
                        ? 'border-teal-500 bg-teal-50/50 shadow-sm ring-1 ring-teal-500/20'
                        : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[11px] font-bold text-slate-500">{p.patientId}</span>
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                        isEmerg
                          ? 'bg-rose-500 text-white'
                          : p.triage?.urgencyLevel === 'Urgent Care'
                          ? 'bg-amber-500 text-white'
                          : 'bg-emerald-500 text-white'
                      }`}>
                        {p.triage?.urgencyLevel}
                      </span>
                    </div>

                    <p className="text-xs font-bold text-slate-800">{p.name}</p>
                    <div className="flex justify-between items-center text-[11px] text-slate-500 mt-1">
                      <span>{p.age}y / {p.gender} • SpO₂: <strong className={p.vitals.spo2 < 90 ? 'text-rose-600' : ''}>{p.vitals.spo2}%</strong></span>
                      <span className="font-semibold text-teal-700">{p.doctorReview?.status || 'Pending'}</span>
                    </div>
                  </button>
                );
              })
            )}
          </div>

        </div>

        {/* Right Column: Selected Patient Detail Panel (8 cols) */}
        {selectedPatient ? (
          <div className="lg:col-span-8 space-y-5">
            
            {/* Top Detail Card */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
              
              <div className="flex flex-wrap justify-between items-start gap-2 border-b border-slate-100 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-slate-900">{selectedPatient.name}</h3>
                    <span className="font-mono text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                      {selectedPatient.patientId}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Registered: {new Date(selectedPatient.createdAt).toLocaleString()}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-xl text-xs font-extrabold uppercase ${
                    selectedPatient.triage?.urgencyLevel === 'Emergency'
                      ? 'bg-rose-600 text-white'
                      : 'bg-amber-500 text-white'
                  }`}>
                    {selectedPatient.triage?.urgencyLevel} Triage
                  </span>
                </div>
              </div>

              {/* Vitals & Demographics Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block font-semibold">SpO₂ Level</span>
                  <span className={`text-base font-black font-mono ${selectedPatient.vitals.spo2 < 90 ? 'text-rose-600' : 'text-slate-800'}`}>
                    {selectedPatient.vitals.spo2}%
                  </span>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block font-semibold">Heart Rate</span>
                  <span className="text-base font-black font-mono text-slate-800">
                    {selectedPatient.vitals.heartRate} <span className="text-xs font-normal">bpm</span>
                  </span>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block font-semibold">Temperature</span>
                  <span className="text-base font-black font-mono text-slate-800">
                    {selectedPatient.vitals.temperature}°F
                  </span>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block font-semibold">Blood Pressure</span>
                  <span className="text-base font-black font-mono text-slate-800">
                    {selectedPatient.vitals.bpSystolic}/{selectedPatient.vitals.bpDiastolic}
                  </span>
                </div>
              </div>

              {/* Voice Transcript & Extracted Symptoms */}
              <div className="space-y-2 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <span className="font-bold text-slate-700 block">Voice Transcript & Extracted Symptoms:</span>
                <p className="italic text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200">
                  "{selectedPatient.symptoms.rawTranscript || 'No voice transcript recorded'}"
                </p>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {selectedPatient.symptoms.extractedSymptoms.map((sym, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 text-indigo-800">
                      {sym}
                    </span>
                  ))}
                </div>
              </div>

              {/* Chest X-Ray AI Analysis Section */}
              {selectedPatient.xray && (
                <div className="space-y-2">
                  <span className="font-bold text-xs text-slate-700 block">
                    COVID-Net Chest Radiograph AI Analysis
                  </span>
                  <HeatmapViewer xray={selectedPatient.xray} />
                </div>
              )}

              {/* Triage Referral Recommendation */}
              <div className="p-4 bg-teal-50 border border-teal-200 rounded-xl space-y-1 text-xs text-teal-950">
                <span className="font-bold uppercase tracking-wider text-[10px] text-teal-700 block">
                  AI Target Specialty Recommendation
                </span>
                <p className="text-base font-black">{selectedPatient.triage?.recommendedSpecialty}</p>
                <p className="text-slate-700"><strong>Action Protocol:</strong> {selectedPatient.triage?.recommendedAction}</p>
              </div>

            </div>

            {/* Doctor Review & Override Controls */}
            <form onSubmit={handleSaveReview} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <Edit3 className="w-5 h-5 text-indigo-600" />
                <h4 className="font-bold text-slate-800 text-sm">Doctor Review & Clinical Sign-off</h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Attending Clinician Name</label>
                  <input
                    type="text"
                    value={reviewerName}
                    onChange={e => setReviewerName(e.target.value)}
                    className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Review Decision Status</label>
                  <select
                    value={reviewStatus}
                    onChange={e => setReviewStatus(e.target.value as any)}
                    className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800"
                  >
                    <option value="Approved">Approved AI Triage</option>
                    <option value="Overridden">Overridden Specialty/Priority</option>
                    <option value="Discharged">Discharged / Cleared</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1 text-xs">Clinical Notes & Treatment Orders</label>
                <textarea
                  rows={3}
                  placeholder="Enter clinical examination notes, lab orders (e.g. RT-PCR, ABG), or isolation room assignments..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-all"
                >
                  <Check className="w-4 h-4" />
                  <span>{isSubmitting ? 'Saving...' : 'Save MD Sign-off & Update Status'}</span>
                </button>
              </div>
            </form>

          </div>
        ) : (
          <div className="lg:col-span-8 bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-400">
            Select a patient from the queue to view full clinical details
          </div>
        )}

      </div>
    </div>
  );
};
