import React, { useState } from 'react';
import { COVID_NET_PAPER_BENCHMARKS, CLINICAL_SAFETY_EXPLANATION } from '../data/covidNetMetrics';
import { SAMPLE_CHEST_XRAYS } from '../data/sampleXRays';
import { HeatmapViewer } from './HeatmapViewer';
import { BarChart3, ShieldAlert, CheckCircle2, AlertTriangle, Layers, Info, Award, Zap, HelpCircle } from 'lucide-react';

export const CovidNetMetricsView: React.FC = () => {
  const [selectedBenchmarkCase, setSelectedBenchmarkCase] = useState<string>('covid_severe');
  const metrics = COVID_NET_PAPER_BENCHMARKS;
  const currentXRay = SAMPLE_CHEST_XRAYS[selectedBenchmarkCase];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Top Paper Header */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-teal-500/20 text-teal-300 border border-teal-500/40">
                arXiv:2003.09871
              </span>
              <span className="text-xs text-slate-400">Wang et al. (COVIDx Dataset)</span>
            </div>
            <h2 className="text-2xl font-black mt-1">COVID-Net Model Evaluation & Safety Metrics</h2>
          </div>

          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <span className="text-xs text-slate-300 font-semibold">Tailored Deep Neural Network Architecture</span>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-4xl">
          HealthAI's chest radiography classifier is directly motivated by the COVID-Net architecture, designed specifically to address the clinical danger of false-negative infectious disease triage.
        </p>
      </div>

      {/* Headline Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* COVID-19 Sensitivity / Recall - Headline Safety Metric */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-rose-900 to-slate-900 text-white border-2 border-rose-500/80 shadow-lg relative overflow-hidden">
          <div className="absolute right-2 top-2 opacity-15">
            <ShieldAlert className="w-20 h-20 text-rose-300" />
          </div>
          <span className="text-xs font-mono text-rose-300 uppercase tracking-wider font-bold block">
            Headline Safety Metric
          </span>
          <p className="text-3xl font-black font-mono mt-1 text-white">
            {metrics.covid19Sensitivity}%
          </p>
          <span className="text-xs font-bold text-rose-200 block mt-1">
            COVID-19 Sensitivity (Recall)
          </span>
          <p className="text-[11px] text-rose-300/80 mt-2 leading-snug">
            Minimizes False Negatives so contagious respiratory patients are not missed.
          </p>
        </div>

        {/* Positive Predictive Value (PPV) */}
        <div className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-md">
          <span className="text-xs font-mono text-teal-400 uppercase tracking-wider font-bold block">
            Precision
          </span>
          <p className="text-3xl font-black font-mono mt-1 text-teal-200">
            {metrics.covid19PPV}%
          </p>
          <span className="text-xs font-bold text-slate-300 block mt-1">
            Positive Predictive Value (PPV)
          </span>
          <p className="text-[11px] text-slate-400 mt-2 leading-snug">
            High confidence when COVID-19 prediction is triggered.
          </p>
        </div>

        {/* Specificity */}
        <div className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-md">
          <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-bold block">
            Specificity
          </span>
          <p className="text-3xl font-black font-mono mt-1 text-cyan-200">
            {metrics.covid19Specificity}%
          </p>
          <span className="text-xs font-bold text-slate-300 block mt-1">
            Normal/Non-COVID Specificity
          </span>
          <p className="text-[11px] text-slate-400 mt-2 leading-snug">
            Prevents false alarms for normal non-infected radiography.
          </p>
        </div>

        {/* Overall Accuracy */}
        <div className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-md">
          <span className="text-xs font-mono text-emerald-400 uppercase tracking-wider font-bold block">
            Overall Accuracy
          </span>
          <p className="text-3xl font-black font-mono mt-1 text-emerald-200">
            {metrics.accuracy}%
          </p>
          <span className="text-xs font-bold text-slate-300 block mt-1">
            Multi-Class Accuracy (COVIDx)
          </span>
          <p className="text-[11px] text-slate-400 mt-2 leading-snug">
            Across 1,579 test cases (COVID-19, Pneumonia, Normal).
          </p>
        </div>

      </div>

      {/* Clinical Safety Rationale Section */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 text-amber-950 space-y-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-amber-700" />
          <h3 className="font-extrabold text-sm text-amber-900">{CLINICAL_SAFETY_EXPLANATION.title}</h3>
        </div>
        <p className="text-xs leading-relaxed text-amber-900">
          {CLINICAL_SAFETY_EXPLANATION.body}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1 text-xs">
          {CLINICAL_SAFETY_EXPLANATION.keyTakeaways.map((takeaway, idx) => (
            <div key={idx} className="bg-white/80 p-3 rounded-xl border border-amber-200 font-medium">
              <span className="text-amber-800 font-bold block mb-0.5">• Clinical Advantage</span>
              <span>{takeaway}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 3x3 Confusion Matrix & Test Bench Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Confusion Matrix (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <BarChart3 className="w-5 h-5 text-teal-600" />
            <div>
              <h3 className="font-bold text-slate-800 text-sm">3x3 Confusion Matrix (COVIDx Dataset)</h3>
              <p className="text-xs text-slate-500">Actual vs AI Model Predicted Categories</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-center border-collapse">
              <thead>
                <tr className="bg-slate-100 font-bold text-slate-700">
                  <th className="p-2 border border-slate-200 text-left">Actual \ Predicted</th>
                  <th className="p-2 border border-slate-200 text-rose-700 bg-rose-50">COVID-19</th>
                  <th className="p-2 border border-slate-200 text-amber-700 bg-amber-50">Non-COVID</th>
                  <th className="p-2 border border-slate-200 text-emerald-700 bg-emerald-50">Normal</th>
                </tr>
              </thead>
              <tbody>
                {/* Actual COVID-19 */}
                <tr>
                  <td className="p-2.5 font-bold text-rose-800 bg-rose-50 border border-slate-200 text-left">
                    COVID-19
                  </td>
                  <td className="p-2.5 font-black bg-rose-500 text-white border border-slate-200">
                    91 (91.0%)
                  </td>
                  <td className="p-2.5 bg-rose-100/80 text-rose-900 border border-slate-200 font-bold">
                    7 (7.0%)
                  </td>
                  <td className="p-2.5 bg-slate-100 text-slate-600 border border-slate-200">
                    2 (2.0%)
                  </td>
                </tr>

                {/* Actual Non-COVID */}
                <tr>
                  <td className="p-2.5 font-bold text-amber-800 bg-amber-50 border border-slate-200 text-left">
                    Non-COVID Pneumonia
                  </td>
                  <td className="p-2.5 bg-slate-100 text-slate-600 border border-slate-200">
                    1 (0.1%)
                  </td>
                  <td className="p-2.5 font-black bg-amber-500 text-white border border-slate-200">
                    887 (94.2%)
                  </td>
                  <td className="p-2.5 bg-amber-100/80 text-amber-900 border border-slate-200">
                    54 (5.7%)
                  </td>
                </tr>

                {/* Actual Normal */}
                <tr>
                  <td className="p-2.5 font-bold text-emerald-800 bg-emerald-50 border border-slate-200 text-left">
                    Normal
                  </td>
                  <td className="p-2.5 bg-slate-100 text-slate-600 border border-slate-200">
                    0 (0.0%)
                  </td>
                  <td className="p-2.5 bg-emerald-100/80 text-emerald-900 border border-slate-200">
                    42 (7.8%)
                  </td>
                  <td className="p-2.5 font-black bg-emerald-500 text-white border border-slate-200">
                    495 (92.2%)
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
            <span className="font-bold text-slate-700 block">Matrix Key Observation:</span>
            <p>
              Only <strong>2 out of 100 actual COVID-19 cases</strong> were misclassified as Normal, demonstrating the strong sensitivity required for frontline safety.
            </p>
          </div>
        </div>

        {/* Interactive Benchmark Test Bench (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Zap className="w-5 h-5 text-amber-500" />
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Interactive Benchmark Test Bench</h3>
              <p className="text-xs text-slate-500">Test model inference response on reference chest radiographs</p>
            </div>
          </div>

          {/* Buttons to switch test bench cases */}
          <div className="flex gap-2 text-xs">
            <button
              type="button"
              onClick={() => setSelectedBenchmarkCase('covid_severe')}
              className={`flex-1 py-2 px-3 rounded-lg font-bold border transition-all ${
                selectedBenchmarkCase === 'covid_severe'
                  ? 'bg-rose-600 text-white border-rose-700'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              COVID-19 Test Case
            </button>

            <button
              type="button"
              onClick={() => setSelectedBenchmarkCase('non_covid_pneumonia')}
              className={`flex-1 py-2 px-3 rounded-lg font-bold border transition-all ${
                selectedBenchmarkCase === 'non_covid_pneumonia'
                  ? 'bg-amber-600 text-white border-amber-700'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Non-COVID Test Case
            </button>

            <button
              type="button"
              onClick={() => setSelectedBenchmarkCase('normal_cxr')}
              className={`flex-1 py-2 px-3 rounded-lg font-bold border transition-all ${
                selectedBenchmarkCase === 'normal_cxr'
                  ? 'bg-emerald-600 text-white border-emerald-700'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Normal Test Case
            </button>
          </div>

          {/* Test Case Heatmap Display */}
          <HeatmapViewer xray={currentXRay} />

        </div>

      </div>

    </div>
  );
};
