import React, { useState } from 'react';
import { PatientProfile, VitalSigns, VoiceSymptomData, ChestXRayData } from '../types';
import { VitalSignsEntry } from './VitalSignsEntry';
import { VoiceSymptomAssistant } from './VoiceSymptomAssistant';
import { ChestXRayAnalyzer } from './ChestXRayAnalyzer';
import { TriageSummaryCard } from './TriageSummaryCard';
import { User, Phone, Stethoscope, Sparkles, AlertCircle, ArrowRight, CheckCircle2, ShieldCheck } from 'lucide-react';

interface PatientIntakeFormProps {
  onPatientCreated: (patient: PatientProfile) => void;
  initialPatientData?: Partial<PatientProfile>;
}

export const PatientIntakeForm: React.FC<PatientIntakeFormProps> = ({ onPatientCreated, initialPatientData }) => {
  const [name, setName] = useState(initialPatientData?.name || '');
  const [age, setAge] = useState(initialPatientData?.age || 45);
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>(initialPatientData?.gender || 'Male');
  const [phone, setPhone] = useState(initialPatientData?.phone || '');
  const [comorbidities, setComorbidities] = useState<string>(
    initialPatientData?.medicalHistory?.join(', ') || ''
  );

  const [vitals, setVitals] = useState<VitalSigns>(
    initialPatientData?.vitals || {
      spo2: 97,
      bpSystolic: 120,
      bpDiastolic: 80,
      heartRate: 75,
      temperature: 98.6,
      weight: 70,
      respiratoryRate: 16
    }
  );

  const [symptoms, setSymptoms] = useState<VoiceSymptomData>(
    initialPatientData?.symptoms || {
      rawTranscript: '',
      extractedSymptoms: [],
      onsetDays: 3,
      feverPresent: false,
      coughSeverity: 'none',
      dyspneaSeverity: 'none',
      lossOfSmellTaste: false,
      fatigue: false,
      chestPain: false,
      otherSymptoms: '',
      additionalNotes: ''
    }
  );

  const [xray, setXray] = useState<ChestXRayData | undefined>(initialPatientData?.xray);

  const [generatedPatient, setGeneratedPatient] = useState<PatientProfile | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleRunTriage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);

    if (!name.trim()) {
      setErrorMsg('Please enter patient name or identifier.');
      return;
    }

    setIsEvaluating(true);

    try {
      // Send vitals, symptoms, xray to backend /api/triage/assess
      const res = await fetch('/api/triage/assess', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vitals, symptoms, xray })
      });

      if (!res.ok) throw new Error('Triage calculation error');

      const triage = await res.json();

      const newPatient: PatientProfile = {
        id: `pat-${Date.now()}`,
        patientId: `PAT-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        name: name.trim(),
        age: Number(age),
        gender,
        phone: phone.trim(),
        medicalHistory: comorbidities.split(',').map(s => s.trim()).filter(Boolean),
        createdAt: new Date().toISOString(),
        vitals,
        symptoms,
        xray,
        triage,
        doctorReview: {
          reviewedBy: '',
          status: 'Pending',
          clinicalNotes: '',
          reviewedAt: ''
        }
      };

      setGeneratedPatient(newPatient);
      setIsSaved(false);
    } catch (err: any) {
      setErrorMsg('Failed to run triage evaluation. Please check your network connection.');
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleSaveToQueue = async () => {
    if (!generatedPatient) return;

    try {
      const res = await fetch('/api/patients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(generatedPatient)
      });

      if (!res.ok) throw new Error('Failed to save to patient queue');

      const saved: PatientProfile = await res.json();
      setIsSaved(true);
      onPatientCreated(saved);
    } catch (e: any) {
      setErrorMsg('Error saving patient profile to queue.');
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Step 1: Patient Demographics */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <div className="p-2 rounded-lg bg-teal-50 text-teal-600">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 text-base">Step 1: Patient Identification & Demographics</h3>
            <p className="text-xs text-slate-500">Enter general patient registration details</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="font-bold text-slate-700 block mb-1">Patient Full Name *</label>
            <input
              type="text"
              required
              placeholder="e.g. John Doe"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full text-sm font-medium text-slate-800 bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Age (Years)</label>
            <input
              type="number"
              min="1"
              max="115"
              value={age}
              onChange={e => setAge(Number(e.target.value))}
              className="w-full text-sm font-medium text-slate-800 bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Gender</label>
            <select
              value={gender}
              onChange={e => setGender(e.target.value as any)}
              className="w-full text-sm font-medium text-slate-800 bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Contact Phone</label>
            <input
              type="text"
              placeholder="+1 (555) 000-0000"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full text-sm font-medium text-slate-800 bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>

        <div>
          <label className="font-bold text-slate-700 block mb-1 text-xs">Medical Comorbidities / History</label>
          <input
            type="text"
            placeholder="e.g. Hypertension, Diabetes, Asthma, Chronic Heart Disease (comma separated)"
            value={comorbidities}
            onChange={e => setComorbidities(e.target.value)}
            className="w-full text-xs font-medium text-slate-800 bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
      </div>

      {/* Step 2: Vital Signs Entry */}
      <VitalSignsEntry vitals={vitals} setVitals={setVitals} />

      {/* Step 3: Voice Symptom Collection */}
      <VoiceSymptomAssistant symptoms={symptoms} setSymptoms={setSymptoms} />

      {/* Step 4: Chest X-Ray Screening */}
      <ChestXRayAnalyzer xray={xray} setXray={setXray} />

      {errorMsg && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Run Triage Evaluation CTA */}
      <div className="flex justify-center pt-2">
        <button
          type="button"
          onClick={() => handleRunTriage()}
          disabled={isEvaluating}
          className="flex items-center gap-3 bg-gradient-to-r from-teal-600 via-cyan-600 to-indigo-600 hover:from-teal-700 hover:to-indigo-700 text-white px-8 py-3.5 rounded-2xl font-black text-base shadow-xl shadow-teal-500/20 transform active:scale-95 transition-all"
        >
          <Sparkles className="w-5 h-5 text-amber-300" />
          <span>Execute Unified AI Triage Assessment</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>

      {/* Generated Triage Summary Result Card */}
      {generatedPatient && (
        <div className="pt-4 space-y-4">
          <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm bg-emerald-50 p-3 rounded-xl border border-emerald-200">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span>AI Triage Decision Stream Successfully Computed</span>
          </div>

          <TriageSummaryCard
            patient={generatedPatient}
            onSaveToQueue={handleSaveToQueue}
            isSaved={isSaved}
          />
        </div>
      )}

    </div>
  );
};
