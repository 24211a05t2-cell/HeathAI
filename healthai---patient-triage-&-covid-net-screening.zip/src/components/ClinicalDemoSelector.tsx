import React from 'react';
import { PatientProfile } from '../types';
import { INITIAL_SAMPLE_PATIENTS } from '../data/samplePatients';
import { Sparkles, ShieldAlert, AlertCircle, CheckCircle, ArrowRight, Activity, Thermometer, Gauge } from 'lucide-react';

interface ClinicalDemoSelectorProps {
  onSelectDemo: (patient: PatientProfile) => void;
}

export const ClinicalDemoSelector: React.FC<ClinicalDemoSelectorProps> = ({ onSelectDemo }) => {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 space-y-2">
        <div className="flex items-center gap-2 text-amber-400">
          <Sparkles className="w-5 h-5" />
          <h2 className="text-xl font-bold">Preset Clinical Demonstration Scenarios</h2>
        </div>
        <p className="text-xs text-slate-300">
          Load fully pre-configured clinical cases into the intake engine to evaluate how HealthAI combines voice symptoms, vital sign thresholds, and chest X-ray classifiers for instant triage.
        </p>
      </div>

      {/* Grid of 3 Preset Cases */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Case 1: Marcus Vance - Severe Emergency COVID-19 */}
        <div className="bg-white rounded-2xl p-5 border-2 border-rose-300 shadow-md space-y-4 hover:border-rose-500 transition-all flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="text-xs font-black px-2.5 py-1 rounded-full bg-rose-600 text-white flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" /> Emergency Triage
              </span>
              <span className="font-mono text-xs text-slate-400 font-bold">
                {INITIAL_SAMPLE_PATIENTS[0].patientId}
              </span>
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900">{INITIAL_SAMPLE_PATIENTS[0].name}</h3>
              <p className="text-xs text-slate-500">{INITIAL_SAMPLE_PATIENTS[0].age}y / {INITIAL_SAMPLE_PATIENTS[0].gender} • Diabetes & HTN</p>
            </div>

            {/* Vital Signs Breakdown */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-rose-50 border border-rose-200">
                <span className="text-[10px] text-slate-500 block">SpO₂ Level</span>
                <span className="text-sm font-black font-mono text-rose-700">89% (Critical)</span>
              </div>

              <div className="p-2 rounded-lg bg-rose-50 border border-rose-200">
                <span className="text-[10px] text-slate-500 block">Temperature</span>
                <span className="text-sm font-black font-mono text-rose-700">102.4°F</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200 italic line-clamp-3">
              "{INITIAL_SAMPLE_PATIENTS[0].symptoms.rawTranscript}"
            </p>

            <div className="p-2 rounded-lg bg-rose-100/60 text-rose-950 text-xs font-bold">
              CXR: Ground-Glass Opacities (94.2% COVID-19)
            </div>
          </div>

          <button
            type="button"
            onClick={() => onSelectDemo(INITIAL_SAMPLE_PATIENTS[0])}
            className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center gap-2 shadow-sm transition-all"
          >
            <span>Load Emergency COVID-19 Demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Case 2: Elena Rostova - Moderate Bacterial Pneumonia */}
        <div className="bg-white rounded-2xl p-5 border-2 border-amber-300 shadow-md space-y-4 hover:border-amber-500 transition-all flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-amber-500 text-white flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Moderate Triage
              </span>
              <span className="font-mono text-xs text-slate-400 font-bold">
                {INITIAL_SAMPLE_PATIENTS[1].patientId}
              </span>
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900">{INITIAL_SAMPLE_PATIENTS[1].name}</h3>
              <p className="text-xs text-slate-500">{INITIAL_SAMPLE_PATIENTS[1].age}y / {INITIAL_SAMPLE_PATIENTS[1].gender} • Mild Asthma</p>
            </div>

            {/* Vital Signs Breakdown */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 block">SpO₂ Level</span>
                <span className="text-sm font-black font-mono text-slate-800">95% (Stable)</span>
              </div>

              <div className="p-2 rounded-lg bg-amber-50 border border-amber-200">
                <span className="text-[10px] text-slate-500 block">Temperature</span>
                <span className="text-sm font-black font-mono text-amber-700">100.8°F</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200 italic line-clamp-3">
              "{INITIAL_SAMPLE_PATIENTS[1].symptoms.rawTranscript}"
            </p>

            <div className="p-2 rounded-lg bg-amber-100/60 text-amber-950 text-xs font-bold">
              CXR: Lobar Consolidation (88.5% Non-COVID)
            </div>
          </div>

          <button
            type="button"
            onClick={() => onSelectDemo(INITIAL_SAMPLE_PATIENTS[1])}
            className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white flex items-center justify-center gap-2 shadow-sm transition-all"
          >
            <span>Load Bacterial Pneumonia Demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Case 3: David Kim - Routine Clear Check-up */}
        <div className="bg-white rounded-2xl p-5 border-2 border-emerald-300 shadow-md space-y-4 hover:border-emerald-500 transition-all flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-600 text-white flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Routine Triage
              </span>
              <span className="font-mono text-xs text-slate-400 font-bold">
                {INITIAL_SAMPLE_PATIENTS[2].patientId}
              </span>
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900">{INITIAL_SAMPLE_PATIENTS[2].name}</h3>
              <p className="text-xs text-slate-500">{INITIAL_SAMPLE_PATIENTS[2].age}y / {INITIAL_SAMPLE_PATIENTS[2].gender} • No Comorbidities</p>
            </div>

            {/* Vital Signs Breakdown */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-200">
                <span className="text-[10px] text-slate-500 block">SpO₂ Level</span>
                <span className="text-sm font-black font-mono text-emerald-700">99% (Normal)</span>
              </div>

              <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-200">
                <span className="text-[10px] text-slate-500 block">Temperature</span>
                <span className="text-sm font-black font-mono text-emerald-700">98.6°F</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200 italic line-clamp-3">
              "{INITIAL_SAMPLE_PATIENTS[2].symptoms.rawTranscript}"
            </p>

            <div className="p-2 rounded-lg bg-emerald-100/60 text-emerald-950 text-xs font-bold">
              CXR: Clear Lung Fields (98.0% Normal)
            </div>
          </div>

          <button
            type="button"
            onClick={() => onSelectDemo(INITIAL_SAMPLE_PATIENTS[2])}
            className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-2 shadow-sm transition-all"
          >
            <span>Load Routine Clearance Demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
