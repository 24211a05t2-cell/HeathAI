import React from 'react';
import { VitalSigns } from '../types';
import { Activity, Heart, Thermometer, Gauge, Scale, AlertTriangle, CheckCircle2, Zap } from 'lucide-react';

interface VitalSignsEntryProps {
  vitals: VitalSigns;
  setVitals: React.Dispatch<React.SetStateAction<VitalSigns>>;
}

export const VitalSignsEntry: React.FC<VitalSignsEntryProps> = ({ vitals, setVitals }) => {
  const handleChange = (field: keyof VitalSigns, value: number) => {
    setVitals(prev => ({ ...prev, [field]: value }));
  };

  const setNormalPreset = () => {
    setVitals({
      spo2: 98,
      bpSystolic: 118,
      bpDiastolic: 76,
      heartRate: 72,
      temperature: 98.6,
      weight: 70,
      respiratoryRate: 15
    });
  };

  const setHypoxicPreset = () => {
    setVitals({
      spo2: 88,
      bpSystolic: 145,
      bpDiastolic: 92,
      heartRate: 115,
      temperature: 102.2,
      weight: 82,
      respiratoryRate: 26
    });
  };

  return (
    <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-teal-50 text-teal-600">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 text-base">First-Level Vital Measurements</h3>
            <p className="text-xs text-slate-500">Collect baseline patient physiological parameters</p>
          </div>
        </div>

        {/* Preset Fill Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={setNormalPreset}
            className="flex items-center gap-1 text-xs font-medium px-2.5 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors border border-emerald-200"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Normal Preset
          </button>
          <button
            type="button"
            onClick={setHypoxicPreset}
            className="flex items-center gap-1 text-xs font-medium px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors border border-rose-200"
          >
            <Zap className="w-3.5 h-3.5" />
            Hypoxic Critical Preset
          </button>
        </div>
      </div>

      {/* Grid of Vital Sign Inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        
        {/* SpO2 */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          vitals.spo2 < 90
            ? 'bg-rose-50/70 border-rose-300 ring-2 ring-rose-400/20'
            : vitals.spo2 < 94
            ? 'bg-amber-50/70 border-amber-300'
            : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex justify-between items-center mb-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Gauge className="w-4 h-4 text-cyan-600" />
              Oxygen Saturation (SpO₂)
            </label>
            <span className="text-xs text-slate-400">%</span>
          </div>
          <input
            type="number"
            min="50"
            max="100"
            value={vitals.spo2}
            onChange={e => handleChange('spo2', Number(e.target.value))}
            className="w-full text-2xl font-black text-slate-800 bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
          <div className="mt-2 text-xs">
            {vitals.spo2 < 90 ? (
              <span className="font-bold text-rose-600 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Severe Hypoxia (&lt;90%)
              </span>
            ) : vitals.spo2 < 94 ? (
              <span className="font-bold text-amber-600 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Mild Hypoxia (90-93%)
              </span>
            ) : (
              <span className="text-emerald-600 font-medium">Normal Saturation (≥95%)</span>
            )}
          </div>
        </div>

        {/* Heart Rate */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          vitals.heartRate > 100 || vitals.heartRate < 60
            ? 'bg-amber-50/70 border-amber-300'
            : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex justify-between items-center mb-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-rose-500" />
              Heart Rate (Pulse)
            </label>
            <span className="text-xs text-slate-400">BPM</span>
          </div>
          <input
            type="number"
            min="30"
            max="220"
            value={vitals.heartRate}
            onChange={e => handleChange('heartRate', Number(e.target.value))}
            className="w-full text-2xl font-black text-slate-800 bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
          <div className="mt-2 text-xs">
            {vitals.heartRate > 100 ? (
              <span className="font-bold text-amber-600">Tachycardia (&gt;100 bpm)</span>
            ) : vitals.heartRate < 60 ? (
              <span className="font-medium text-slate-500">Bradycardia (&lt;60 bpm)</span>
            ) : (
              <span className="text-emerald-600 font-medium">Normal Pulse (60-100)</span>
            )}
          </div>
        </div>

        {/* Temperature */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          vitals.temperature >= 100.4
            ? 'bg-rose-50/70 border-rose-300'
            : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex justify-between items-center mb-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Thermometer className="w-4 h-4 text-orange-500" />
              Body Temperature
            </label>
            <span className="text-xs text-slate-400">°F</span>
          </div>
          <input
            type="number"
            step="0.1"
            min="90"
            max="110"
            value={vitals.temperature}
            onChange={e => handleChange('temperature', Number(e.target.value))}
            className="w-full text-2xl font-black text-slate-800 bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
          <div className="mt-2 text-xs">
            {vitals.temperature >= 102.0 ? (
              <span className="font-bold text-rose-600">High Pyrexia (≥102°F)</span>
            ) : vitals.temperature >= 100.4 ? (
              <span className="font-bold text-orange-600">Fever (≥100.4°F)</span>
            ) : (
              <span className="text-emerald-600 font-medium">Afebrile (Normal)</span>
            )}
          </div>
        </div>

        {/* Blood Pressure */}
        <div className="p-3.5 rounded-xl border bg-slate-50 border-slate-200">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-1.5">
            <Activity className="w-4 h-4 text-indigo-500" />
            Blood Pressure (Systolic / Diastolic)
          </label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              placeholder="Sys"
              value={vitals.bpSystolic}
              onChange={e => handleChange('bpSystolic', Number(e.target.value))}
              className="w-1/2 text-xl font-bold text-slate-800 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-center focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <span className="text-slate-400 font-bold">/</span>
            <input
              type="number"
              placeholder="Dia"
              value={vitals.bpDiastolic}
              onChange={e => handleChange('bpDiastolic', Number(e.target.value))}
              className="w-1/2 text-xl font-bold text-slate-800 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-center focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>
          <div className="mt-2 text-xs text-slate-500">
            {vitals.bpSystolic >= 140 || vitals.bpDiastolic >= 90 ? (
              <span className="font-bold text-amber-600">Stage 2 Hypertensive</span>
            ) : (
              <span>Normal BP (&lt;120/80)</span>
            )}
          </div>
        </div>

        {/* Respiratory Rate */}
        <div className={`p-3.5 rounded-xl border transition-all ${
          vitals.respiratoryRate > 20
            ? 'bg-amber-50/70 border-amber-300'
            : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex justify-between items-center mb-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-teal-600" />
              Respiratory Rate
            </label>
            <span className="text-xs text-slate-400">breaths/min</span>
          </div>
          <input
            type="number"
            min="8"
            max="60"
            value={vitals.respiratoryRate}
            onChange={e => handleChange('respiratoryRate', Number(e.target.value))}
            className="w-full text-2xl font-black text-slate-800 bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
          <div className="mt-2 text-xs">
            {vitals.respiratoryRate > 24 ? (
              <span className="font-bold text-rose-600">Severe Tachypnea (&gt;24)</span>
            ) : vitals.respiratoryRate > 20 ? (
              <span className="font-bold text-amber-600">Elevated RR (21-24)</span>
            ) : (
              <span className="text-emerald-600 font-medium">Normal RR (12-20)</span>
            )}
          </div>
        </div>

        {/* Weight */}
        <div className="p-3.5 rounded-xl border bg-slate-50 border-slate-200">
          <div className="flex justify-between items-center mb-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-slate-500" />
              Body Weight
            </label>
            <span className="text-xs text-slate-400">kg</span>
          </div>
          <input
            type="number"
            value={vitals.weight}
            onChange={e => handleChange('weight', Number(e.target.value))}
            className="w-full text-2xl font-black text-slate-800 bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
          <div className="mt-2 text-xs text-slate-400">
            ~ {(vitals.weight * 2.20462).toFixed(1)} lbs
          </div>
        </div>

      </div>
    </div>
  );
};
