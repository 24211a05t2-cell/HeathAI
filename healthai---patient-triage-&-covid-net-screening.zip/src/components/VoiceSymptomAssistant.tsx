import React, { useState, useEffect } from 'react';
import { VoiceSymptomData } from '../types';
import { Mic, MicOff, Volume2, Sparkles, AlertCircle, Clock, Check, Loader2, MessageSquareText } from 'lucide-react';

interface VoiceSymptomAssistantProps {
  symptoms: VoiceSymptomData;
  setSymptoms: React.Dispatch<React.SetStateAction<VoiceSymptomData>>;
}

export const VoiceSymptomAssistant: React.FC<VoiceSymptomAssistantProps> = ({ symptoms, setSymptoms }) => {
  const [transcriptInput, setTranscriptInput] = useState(symptoms.rawTranscript);
  const [isListening, setIsListening] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Check Web Speech API support
  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      setSpeechSupported(true);
    }
  }, []);

  const handleToggleListening = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorMsg("Speech recognition is not supported in this browser environment. You can type or paste the patient's spoken description below.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setErrorMsg(null);
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = 0; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript + ' ';
        }
        setTranscriptInput(currentTranscript.trim());
      };

      recognition.onerror = (event: any) => {
        console.warn("Speech recognition error:", event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setErrorMsg("Microphone permission was denied. Please type your symptoms manually.");
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (e: any) {
      setIsListening(false);
      setErrorMsg("Could not access microphone. Please type symptom description below.");
    }
  };

  const handleExtractSymptoms = async () => {
    if (!transcriptInput.trim()) return;

    setIsExtracting(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/symptoms/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: transcriptInput })
      });

      if (!res.ok) {
        throw new Error("Server extraction failed");
      }

      const data: VoiceSymptomData = await res.json();
      setSymptoms(data);
    } catch (e: any) {
      setErrorMsg("Voice extraction failed. Please check your text or try again.");
    } finally {
      setIsExtracting(false);
    }
  };

  const sampleVoicePrompts = [
    "I have had a severe dry cough, 102 degree fever, and bad shortness of breath for 3 days. I lost my sense of taste.",
    "Just a mild productive cough with phlegm and 100 fever for 5 days. Chest hurts when taking deep breaths.",
    "Felt tired with slight sore throat and runny nose since yesterday. No fever or shortness of breath."
  ];

  return (
    <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
      
      {/* Title Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
            <Volume2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 text-base">Voice-Based Symptom Collection</h3>
            <p className="text-xs text-slate-500">Patients speak naturally; AI extracts structured clinical risk factors</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>Gemini Voice NLP Engine</span>
        </div>
      </div>

      {/* Voice Input Section */}
      <div className="space-y-3">
        <div className="relative">
          <textarea
            rows={3}
            value={transcriptInput}
            onChange={(e) => setTranscriptInput(e.target.value)}
            placeholder="Click microphone or type symptoms: e.g. 'I've had a severe cough, high fever for 3 days, and shortness of breath...'"
            className="w-full text-sm text-slate-800 bg-slate-50 border border-slate-200 rounded-xl p-3.5 pr-24 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
          />

          <div className="absolute right-3 bottom-3 flex items-center gap-2">
            <button
              type="button"
              onClick={handleToggleListening}
              className={`p-2.5 rounded-xl font-medium transition-all shadow-sm flex items-center gap-1.5 ${
                isListening
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white'
              }`}
              title={isListening ? 'Stop Listening' : 'Start Voice Input'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              <span className="text-xs font-bold">{isListening ? 'Listening...' : 'Voice Mic'}</span>
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Quick Sample Voice Prompts */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
            <MessageSquareText className="w-3.5 h-3.5" /> Sample Inputs:
          </span>
          {sampleVoicePrompts.map((prompt, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setTranscriptInput(prompt);
              }}
              className="text-xs text-indigo-600 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded-lg border border-indigo-200 transition-colors text-left"
            >
              "{prompt.slice(0, 42)}..."
            </button>
          ))}
        </div>

        {/* AI Parse Button */}
        <div className="flex justify-end pt-1">
          <button
            type="button"
            onClick={handleExtractSymptoms}
            disabled={isExtracting || !transcriptInput.trim()}
            className="flex items-center gap-2 bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-sm disabled:opacity-50 transition-all"
          >
            {isExtracting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Extracting Symptoms with AI...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Analyze & Extract Structured Symptoms</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Structured Symptoms Output Display */}
      {symptoms.extractedSymptoms.length > 0 && (
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              AI Extracted Clinical Symptoms
            </span>
            <span className="text-xs font-semibold text-teal-700 flex items-center gap-1">
              <Check className="w-3.5 h-3.5 text-emerald-500" /> Parsed & Validated
            </span>
          </div>

          {/* Badges of Extracted Terms */}
          <div className="flex flex-wrap gap-2">
            {symptoms.extractedSymptoms.map((sym, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-100 text-indigo-800 border border-indigo-200"
              >
                {sym}
              </span>
            ))}
          </div>

          {/* Severity & Feature Matrix */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs">
            
            {/* Cough Severity */}
            <div className="p-2.5 rounded-lg bg-white border border-slate-200">
              <span className="text-slate-500 block mb-1">Cough Severity</span>
              <span className={`font-bold capitalize ${
                symptoms.coughSeverity === 'severe' ? 'text-rose-600' : 'text-slate-800'
              }`}>
                {symptoms.coughSeverity}
              </span>
            </div>

            {/* Dyspnea Severity */}
            <div className={`p-2.5 rounded-lg border ${
              symptoms.dyspneaSeverity === 'severe'
                ? 'bg-rose-50 border-rose-300 text-rose-900'
                : 'bg-white border-slate-200'
            }`}>
              <span className="text-slate-500 block mb-1">Dyspnea (Breathing)</span>
              <span className={`font-bold capitalize ${
                symptoms.dyspneaSeverity === 'severe' ? 'text-rose-600' : 'text-slate-800'
              }`}>
                {symptoms.dyspneaSeverity}
              </span>
            </div>

            {/* Loss of Smell / Taste */}
            <div className={`p-2.5 rounded-lg border ${
              symptoms.lossOfSmellTaste
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-white border-slate-200'
            }`}>
              <span className="text-slate-500 block mb-1">Anosmia / Loss of Taste</span>
              <span className="font-bold">
                {symptoms.lossOfSmellTaste ? '⚠️ YES (Classic Flag)' : 'No'}
              </span>
            </div>

            {/* Onset Days */}
            <div className="p-2.5 rounded-lg bg-white border border-slate-200">
              <span className="text-slate-500 block mb-1">Symptom Duration</span>
              <span className="font-bold text-slate-800 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                {symptoms.onsetDays} {symptoms.onsetDays === 1 ? 'day' : 'days'}
              </span>
            </div>

          </div>

          {symptoms.additionalNotes && (
            <p className="text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200 italic">
              <strong>Clinical Note:</strong> {symptoms.additionalNotes}
            </p>
          )}

        </div>
      )}

    </div>
  );
};
