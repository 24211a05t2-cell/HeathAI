import React, { useState } from 'react';
import { PatientProfile } from '../types';
import { AlertOctagon, AlertTriangle, ShieldCheck, Clock, CheckCircle2, Building, Printer, UserCheck, Share2 } from 'lucide-react';

interface TriageSummaryCardProps {
  patient: PatientProfile;
  onSaveToQueue?: () => void;
  isSaved?: boolean;
}

export const TriageSummaryCard: React.FC<TriageSummaryCardProps> = ({ patient, onSaveToQueue, isSaved = false }) => {
  const [printed, setPrinted] = useState(false);
  const triage = patient.triage;

  if (!triage) return null;

  const handlePrint = () => {
    setPrinted(true);
    window.print();
  };

  const getUrgencyTheme = () => {
    switch (triage.urgencyLevel) {
      case 'Emergency':
        return {
          bg: 'bg-rose-600',
          lightBg: 'bg-rose-50',
          border: 'border-rose-300',
          text: 'text-rose-700',
          icon: <AlertOctagon className="w-6 h-6 text-white" />,
          badge: 'bg-rose-500 text-white font-black'
        };
      case 'Urgent Care':
        return {
          bg: 'bg-amber-600',
          lightBg: 'bg-amber-50',
          border: 'border-amber-300',
          text: 'text-amber-700',
          icon: <AlertTriangle className="w-6 h-6 text-white" />,
          badge: 'bg-amber-500 text-white font-black'
        };
      case 'Moderate Priority':
        return {
          bg: 'bg-yellow-600',
          lightBg: 'bg-yellow-50',
          border: 'border-yellow-300',
          text: 'text-yellow-800',
          icon: <Clock className="w-6 h-6 text-white" />,
          badge: 'bg-yellow-500 text-slate-950 font-bold'
        };
      default:
        return {
          bg: 'bg-emerald-600',
          lightBg: 'bg-emerald-50',
          border: 'border-emerald-300',
          text: 'text-emerald-700',
          icon: <ShieldCheck className="w-6 h-6 text-white" />,
          badge: 'bg-emerald-500 text-white font-bold'
        };
    }
  };

  const theme = getUrgencyTheme();

  return (
    <div className="bg-white rounded-2xl border-2 border-slate-300 shadow-lg overflow-hidden space-y-0 print:border-none print:shadow-none">
      
      {/* Top Banner */}
      <div className={`${theme.bg} text-white p-5 flex items-center justify-between`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur">
            {theme.icon}
          </div>
          <div>
            <span className="text-xs uppercase tracking-wider font-semibold opacity-90 block">
              Triage Assessment Output
            </span>
            <h2 className="text-2xl font-black">{triage.urgencyLevel.toUpperCase()} TRIAGE</h2>
          </div>
        </div>

        <div className="text-right">
          <span className="text-xs opacity-80 block font-mono">Urgency Index</span>
          <span className="text-3xl font-black font-mono">{triage.urgencyScore}</span>
          <span className="text-xs opacity-80">/100</span>
        </div>
      </div>

      <div className="p-5 space-y-4">
        
        {/* Patient Bio Bar */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div>
            <span className="font-mono text-slate-400">Patient ID: </span>
            <strong className="font-mono text-slate-800">{patient.patientId}</strong>
          </div>
          <div>
            <span className="text-slate-400">Name: </span>
            <strong className="text-slate-800">{patient.name || 'Anonymous'}</strong>
          </div>
          <div>
            <span className="text-slate-400">Age/Gender: </span>
            <strong className="text-slate-800">{patient.age}y / {patient.gender}</strong>
          </div>
          <div>
            <span className="text-slate-400">SpO₂: </span>
            <strong className={`font-mono font-bold ${patient.vitals.spo2 < 90 ? 'text-rose-600' : 'text-slate-800'}`}>
              {patient.vitals.spo2}%
            </strong>
          </div>
        </div>

        {/* Primary Specialty Recommendation */}
        <div className={`p-4 rounded-xl border ${theme.lightBg} ${theme.border} space-y-2`}>
          <div className="flex items-center gap-2">
            <Building className={`w-5 h-5 ${theme.text}`} />
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Recommended Medical Specialty & Department
            </span>
          </div>

          <p className="text-lg font-black text-slate-900">
            {triage.recommendedSpecialty}
          </p>

          {triage.secondarySpecialty && (
            <p className="text-xs text-slate-600">
              Secondary Referral: <strong>{triage.secondarySpecialty}</strong>
            </p>
          )}

          <div className="pt-2 border-t border-slate-200/60">
            <span className="text-xs font-bold text-slate-700">Recommended Next Clinical Step:</span>
            <p className="text-xs font-medium text-slate-800 mt-0.5">
              {triage.recommendedAction}
            </p>
          </div>
        </div>

        {/* COVID-19 Suspicion & Risk Flags */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          
          {/* Covid Risk Level */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
            <span className="text-slate-500 block font-semibold">COVID-19 Suspicion Level</span>
            <span className={`inline-block px-2.5 py-1 rounded-lg font-bold ${
              triage.covidRisk === 'High Suspicion'
                ? 'bg-rose-100 text-rose-800 border border-rose-300'
                : triage.covidRisk === 'Moderate Suspicion'
                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
            }`}>
              {triage.covidRisk}
            </span>
          </div>

          {/* CXR Classification */}
          {patient.xray && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <span className="text-slate-500 block font-semibold">Chest X-Ray AI Prediction</span>
              <span className="font-bold text-slate-800 block">
                {patient.xray.predictedClass} ({(patient.xray.confidenceScore).toFixed(1)}%)
              </span>
            </div>
          )}

        </div>

        {/* Clinical Risk Flags */}
        {triage.riskFlags.length > 0 && (
          <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 text-xs space-y-1.5">
            <span className="font-bold text-amber-900 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Key Clinical Risk Indicators
            </span>
            <ul className="space-y-1 pl-1">
              {triage.riskFlags.map((flag, idx) => (
                <li key={idx} className="flex items-start gap-1.5 text-amber-900 font-medium">
                  <span className="text-amber-600 font-bold">•</span>
                  <span>{flag}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Rationale */}
        <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200 italic">
          <strong>Triage Rationale:</strong> {triage.rationale}
        </p>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 print:hidden">
          
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>{printed ? 'Printed Ticket' : 'Print Triage Ticket'}</span>
          </button>

          {onSaveToQueue && (
            <button
              type="button"
              onClick={onSaveToQueue}
              disabled={isSaved}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                isSaved
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-teal-600 hover:bg-teal-700 text-white shadow-md'
              }`}
            >
              {isSaved ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Saved to Hospital Queue</span>
                </>
              ) : (
                <>
                  <UserCheck className="w-4 h-4" />
                  <span>Save Patient Profile to Queue</span>
                </>
              )}
            </button>
          )}

        </div>

      </div>
    </div>
  );
};
