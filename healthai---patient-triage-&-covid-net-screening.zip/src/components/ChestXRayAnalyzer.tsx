import React, { useState } from 'react';
import { ChestXRayData } from '../types';
import { HeatmapViewer } from './HeatmapViewer';
import { SAMPLE_CHEST_XRAYS } from '../data/sampleXRays';
import { Upload, FileImage, Sparkles, AlertCircle, CheckCircle, ShieldAlert, Loader2, Info } from 'lucide-react';

interface ChestXRayAnalyzerProps {
  xray?: ChestXRayData;
  setXray: (xray: ChestXRayData) => void;
}

export const ChestXRayAnalyzer: React.FC<ChestXRayAnalyzerProps> = ({ xray, setXray }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please upload a valid image file (JPEG, PNG, DICOM converted).');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      await runXRayAnalysis(base64, file.name);
    };
    reader.readAsDataURL(file);
  };

  const handlePresetSelect = async (presetKey: string) => {
    setIsAnalyzing(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/xray/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ samplePresetKey: presetKey })
      });
      if (!res.ok) throw new Error('Preset analysis failed');
      const data: ChestXRayData = await res.json();
      setXray(data);
    } catch (e: any) {
      setErrorMsg('Failed to load preset X-ray sample.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const runXRayAnalysis = async (base64Image: string, fileName: string) => {
    setIsAnalyzing(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/xray/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64Image, imageName: fileName })
      });
      if (!res.ok) throw new Error('X-Ray analysis server error');
      const data: ChestXRayData = await res.json();
      setXray(data);
    } catch (e: any) {
      setErrorMsg('Failed to analyze image. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-cyan-50 text-cyan-600">
            <FileImage className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 text-base">Chest Radiography (COVID-Net Classifier)</h3>
            <p className="text-xs text-slate-500">Multiclass screening: COVID-19 vs Non-COVID Infection vs Normal</p>
          </div>
        </div>

        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
          arXiv:2003.09871 Inspired
        </span>
      </div>

      {/* Preset Sample Selector or File Upload */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <button
          type="button"
          onClick={() => handlePresetSelect('covid_severe')}
          disabled={isAnalyzing}
          className={`p-3 rounded-xl border text-left transition-all ${
            xray?.imageName.includes('Covid19')
              ? 'border-rose-500 bg-rose-50/60 ring-2 ring-rose-400/20'
              : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-rose-700 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5" /> Sample 1
            </span>
            <span className="text-[10px] font-mono bg-rose-200 text-rose-800 px-1.5 py-0.5 rounded">
              COVID-19 High
            </span>
          </div>
          <p className="text-xs font-semibold text-slate-800">Severe COVID-19 Pneumonia</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Bilateral Ground Glass Opacities</p>
        </button>

        <button
          type="button"
          onClick={() => handlePresetSelect('non_covid_pneumonia')}
          disabled={isAnalyzing}
          className={`p-3 rounded-xl border text-left transition-all ${
            xray?.imageName.includes('Bacterial')
              ? 'border-amber-500 bg-amber-50/60 ring-2 ring-amber-400/20'
              : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-amber-700 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" /> Sample 2
            </span>
            <span className="text-[10px] font-mono bg-amber-200 text-amber-800 px-1.5 py-0.5 rounded">
              Non-COVID
            </span>
          </div>
          <p className="text-xs font-semibold text-slate-800">Bacterial Pneumonia</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Focal Lobar Consolidation</p>
        </button>

        <button
          type="button"
          onClick={() => handlePresetSelect('normal_cxr')}
          disabled={isAnalyzing}
          className={`p-3 rounded-xl border text-left transition-all ${
            xray?.imageName.includes('Normal')
              ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-400/20'
              : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> Sample 3
            </span>
            <span className="text-[10px] font-mono bg-emerald-200 text-emerald-800 px-1.5 py-0.5 rounded">
              Normal
            </span>
          </div>
          <p className="text-xs font-semibold text-slate-800">Normal Clear CXR</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Clear Pulmonary Fields</p>
        </button>
      </div>

      {/* Upload Custom Image Drag-Drop Field */}
      <div className="relative border-2 border-dashed border-slate-300 hover:border-teal-500 rounded-xl p-4 text-center transition-colors bg-slate-50/50">
        <input
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        <div className="flex flex-col items-center justify-center gap-1 pointer-events-none">
          <Upload className="w-5 h-5 text-teal-600" />
          <p className="text-xs font-semibold text-slate-700">Or Upload Custom Patient Chest X-Ray Image</p>
          <p className="text-[11px] text-slate-400">Supports PNG, JPG, DICOM preview formats</p>
        </div>
      </div>

      {isAnalyzing && (
        <div className="p-6 text-center space-y-2 bg-slate-900 text-white rounded-xl">
          <Loader2 className="w-6 h-6 animate-spin text-teal-400 mx-auto" />
          <p className="text-sm font-semibold">Running COVID-Net Deep Convolutional Analysis...</p>
          <p className="text-xs text-slate-400">Evaluating pulmonary consolidations, GGO features, and saliency maps</p>
        </div>
      )}

      {errorMsg && (
        <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* X-Ray Results View */}
      {xray && !isAnalyzing && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 pt-2">
          
          {/* Heatmap Image Container */}
          <div>
            <HeatmapViewer xray={xray} />
          </div>

          {/* Classification Probabilities & Findings */}
          <div className="space-y-4">
            
            {/* Primary Class Banner */}
            <div className={`p-4 rounded-xl border ${
              xray.predictedClass === 'COVID-19 Infection'
                ? 'bg-rose-50 border-rose-300 text-rose-950'
                : xray.predictedClass === 'Non-COVID-19 Infection'
                ? 'bg-amber-50 border-amber-300 text-amber-950'
                : 'bg-emerald-50 border-emerald-300 text-emerald-950'
            }`}>
              <span className="text-[11px] font-mono uppercase tracking-wider block opacity-75 font-semibold">
                AI Radiography Classification
              </span>
              <div className="flex items-baseline justify-between mt-0.5">
                <span className="text-lg font-black">{xray.predictedClass}</span>
                <span className="text-sm font-mono font-bold">
                  {(xray.confidenceScore).toFixed(1)}% Confidence
                </span>
              </div>
            </div>

            {/* 3-Class Probability Bars */}
            <div className="space-y-2 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <span className="text-xs font-bold text-slate-700 block mb-2">
                COVID-Net Multi-Class Probabilities
              </span>

              {/* COVID-19 */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-rose-700">COVID-19 Infection</span>
                  <span className="font-mono text-slate-800">{(xray.predictions.covid19 * 100).toFixed(1)}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-rose-500 rounded-full transition-all duration-500"
                    style={{ width: `${xray.predictions.covid19 * 100}%` }}
                  />
                </div>
              </div>

              {/* Non-COVID Infection */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-amber-700">Non-COVID-19 Infection</span>
                  <span className="font-mono text-slate-800">{(xray.predictions.nonCovidInfection * 100).toFixed(1)}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full transition-all duration-500"
                    style={{ width: `${xray.predictions.nonCovidInfection * 100}%` }}
                  />
                </div>
              </div>

              {/* Normal */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-emerald-700">Normal / Clear Lungs</span>
                  <span className="font-mono text-slate-800">{(xray.predictions.normal * 100).toFixed(1)}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                    style={{ width: `${xray.predictions.normal * 100}%` }}
                  />
                </div>
              </div>

            </div>

            {/* Findings & Notes */}
            <div className="space-y-2 text-xs">
              <span className="font-bold text-slate-700 block">Radiological Findings:</span>
              <ul className="space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-200">
                {xray.findings.map((f, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-slate-700">
                    <span className="text-teal-500 font-bold">•</span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              {xray.radiologyNotes && (
                <div className="p-2.5 rounded-lg bg-teal-50 border border-teal-200 text-teal-900 text-[11px] flex items-start gap-2">
                  <Info className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span>{xray.radiologyNotes}</span>
                </div>
              )}
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
