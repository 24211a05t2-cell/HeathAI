import React, { useState } from 'react';
import { ChestXRayData } from '../types';
import { Eye, EyeOff, Layers, Activity } from 'lucide-react';

interface HeatmapViewerProps {
  xray: ChestXRayData;
  showOverlayDefault?: boolean;
}

export const HeatmapViewer: React.FC<HeatmapViewerProps> = ({ xray, showOverlayDefault = true }) => {
  const [showOverlay, setShowOverlay] = useState(showOverlayDefault);

  // Define heatmap color based on prediction class
  const getHeatColor = (intensity: number) => {
    if (xray.predictedClass === 'COVID-19 Infection') {
      return `rgba(239, 68, 68, ${0.45 + intensity * 0.35})`; // Red
    } else if (xray.predictedClass === 'Non-COVID-19 Infection') {
      return `rgba(234, 179, 8, ${0.45 + intensity * 0.35})`; // Yellow
    }
    return `rgba(16, 185, 129, ${0.2 + intensity * 0.2})`; // Green
  };

  return (
    <div className="space-y-2">
      {/* Overlay Toggle Toolbar */}
      <div className="flex items-center justify-between text-xs bg-slate-900 text-slate-200 px-3 py-2 rounded-t-xl border border-slate-800">
        <div className="flex items-center gap-2 font-mono">
          <Layers className="w-3.5 h-3.5 text-teal-400" />
          <span className="font-semibold">{xray.imageName}</span>
        </div>

        <button
          type="button"
          onClick={() => setShowOverlay(!showOverlay)}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-bold transition-all ${
            showOverlay
              ? 'bg-teal-500 text-slate-950 shadow-sm'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          {showOverlay ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
          <span>{showOverlay ? 'AI Saliency Heatmap: ON' : 'AI Saliency Heatmap: OFF'}</span>
        </button>
      </div>

      {/* Image Stage Container */}
      <div className="relative w-full aspect-[4/4.5] max-h-[380px] bg-slate-950 rounded-b-xl overflow-hidden border border-slate-800 flex items-center justify-center group">
        
        {/* Underlay Chest Radiograph Image */}
        <img
          src={xray.imageUrl}
          alt={xray.imageName}
          className="w-full h-full object-contain select-none"
        />

        {/* Heatmap Overlay Layer */}
        {showOverlay && xray.heatmapCoordinates.length > 0 && (
          <div className="absolute inset-0 pointer-events-none">
            {xray.heatmapCoordinates.map((point, idx) => (
              <div
                key={idx}
                className="absolute rounded-full transition-all duration-300 animate-pulse"
                style={{
                  left: `${point.x}%`,
                  top: `${point.y}%`,
                  width: `${point.radius * 2}px`,
                  height: `${point.radius * 2}px`,
                  transform: 'translate(-50%, -50%)',
                  backgroundColor: getHeatColor(point.intensity),
                  boxShadow: `0 0 ${point.radius * 1.5}px ${getHeatColor(point.intensity)}`,
                  filter: 'blur(8px)'
                }}
              />
            ))}

            {/* Bounding Labels */}
            {xray.heatmapCoordinates.map((point, idx) => (
              <div
                key={`lbl-${idx}`}
                className="absolute text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-900/90 text-amber-300 border border-amber-500/50 shadow-md whitespace-nowrap pointer-events-auto"
                style={{
                  left: `${point.x}%`,
                  top: `${Math.min(88, point.y + 8)}%`,
                  transform: 'translateX(-50%)'
                }}
              >
                {point.label}
              </div>
            ))}
          </div>
        )}

        {/* Floating Confidence Badge */}
        <div className="absolute top-2 left-2 px-2.5 py-1 rounded-lg bg-slate-950/80 backdrop-blur border border-slate-700/80 text-xs font-mono text-slate-200 flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-teal-400" />
          <span>{xray.predictedClass}: <strong>{(xray.confidenceScore).toFixed(1)}%</strong></span>
        </div>

      </div>
    </div>
  );
};
